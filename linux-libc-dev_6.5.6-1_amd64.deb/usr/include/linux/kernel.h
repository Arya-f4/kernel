/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _LINUX_KERNEL_H
#define _LINUX_KERNEL_H

#include <linux/sysinfo.h>
#include <linux/const.h>

#endif /* _LINUX_KERNEL_H */
